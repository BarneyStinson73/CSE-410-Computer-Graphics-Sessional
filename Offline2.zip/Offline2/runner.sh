
g++ "stage 4".cpp -o task3.exe

./task3.exe